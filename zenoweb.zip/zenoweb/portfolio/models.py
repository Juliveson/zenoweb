from django.db import models

class Media(models.Model):
    """
    Model to store media files (images, videos, etc.) uploaded by users.
    """
    file = models.FileField(upload_to='media/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Media {self.id} - {self.file.name}"
