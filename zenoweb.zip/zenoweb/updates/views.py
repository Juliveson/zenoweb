from django.shortcuts import render

def home(request):
    return render(request, 'updates/home.html')

def news(request):
    return render(request, 'updates/news.html')

def channels(request):
    return render(request, 'updates/channels.html')


