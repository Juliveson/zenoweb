function DisplayResponsiveSection(){
    $('.responsiveness-section').css({
        'transform' : 'translate(-50%, -50%) scale(1)',
    })
}
function HideResponsivenesSection(){
    $('.responsiveness-section').css({
        'transform' : 'translate(-50%, -50%) scale(0)',
    })
}
function DisplayNotice(){
    $("#demoNotice").css({
        'display' : 'flex',
    })

    $("#demoNotice").fadeIn(400);

    // Hide after 5 seconds
    setTimeout(() => {
      hideNotice();
    }, 3000);
}
function hideNotice(){
    $("#demoNotice").fadeOut(300);
}

$(document).ready(function(){
    $('.fa-bars').click(function(){
        DisplayResponsiveSection()
    })

    $('#close-section').click(function(){
        HideResponsivenesSection()
    })
    DisplayNotice();
    $(document).on('click', '#demoNotice', function(e){
        if (!$(e.target).closest("#demoNotice").length) {
            hideNotice();
          }
    })
})